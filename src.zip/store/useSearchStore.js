import { create } from "zustand";

// named export 
export const useSearchStore = create((set) => ({
  searchTerm: "",
  setSearchTerm: (value) => set({ searchTerm: value }),
}));


// 중괄호를 소괄호로 감싼 이유 -> 객체를 바로 반환 
// () => ({})