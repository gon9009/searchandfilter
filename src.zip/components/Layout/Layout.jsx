import React from "react";
import Header from "./Header";
import Sidebar from "./Sidebar";
import { Outlet } from "react-router";
import ClipboardPanel from "./ClipboardPanel";
import { useState } from "react";

function Layout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <>
      <Header onMenuClick={() => setMobileOpen(true)} />
      <main className="container">
        <Sidebar
          isMobileOpen={mobileOpen}
          onClose={() => setMobileOpen(false)}
        />
        <div className="main-wrapper">
          <ClipboardPanel />
          <Outlet />
        </div>
      </main>
      {mobileOpen && (
        <div className="backdrop" onClick={() => setMobileOpen(false)} />
      )}
    </>
  );
}

export default Layout;
